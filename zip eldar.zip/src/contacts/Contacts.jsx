function Contacts(){
    return(
        <section className="contact">
            <div className="container">

            </div>
        </section>
    )
}

export default Contacts