import {BrowserRouter, Switch, Route} from 'react-router-dom'
import Header from './Head/Header'
import Store from './catalogue/Store'
import Main from './mainpage/Main'
import Contacts from './contacts/Contacts'
import './Head/menu.css'
import Aboutus from './about/Aboutus'
import './style.css'

function App() {
  return (
    <BrowserRouter>
    <Header />
    
    <Route exact path="/">
      <Main />

    </Route>
    
    


    


    <Switch>
      
      <Route path="/main">
        <Main />

      </Route>
      

      <Route path="/about-page">
        <Aboutus />

      </Route>
      

      <Route path="/store">
        <Store />

      </Route>

      <Route path="/call">
        <Contacts />
      </Route>

    </Switch>
    
    
    </BrowserRouter>
  );
}

export default App;
