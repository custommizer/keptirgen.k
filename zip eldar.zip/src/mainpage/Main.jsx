import React from 'react'


function Main() {
    return(
        <div className="main-content">

        <section className="main">
            <div className="container">
                <div className="main-inner">
                    
                    <h1>Keptirgen</h1>
                    <h5>since 2021</h5>
                    <p>Казахстанская компания<br></br> по производству сущенных продуктов.</p>
                    <button>Подробнее</button>
                </div>
            </div>
        </section>

        <div className="suchofrukt">
            <div className="container">
                <div className="polza-inner">
                    <h1>Почему сущенные продукты так полезны?</h1>
                </div>
            </div>
                
        </div>

        </div>
    )
}

export default Main;