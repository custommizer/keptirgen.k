import React from 'react'
import './store.css'
import storecomponents from './Storecomp';
import Storecomp from './Storecomp'



function Store() {
    return (
        <section className="store">
            <div className="container">
                <div className="store-inner">
                    <div className="store-list">
                        {
                            storecomponents.map((item)=>{
                                return(
                                    <div className="store_item">
                                        <img src={item.image} />
                                        <h1>{item.title}</h1>
                                        <p>{item.description}</p>
                                        <h4>{item.price}</h4>
                                        <button>в Корзинку</button>
                                    </div>
                                )
                            })
                        }
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Store;