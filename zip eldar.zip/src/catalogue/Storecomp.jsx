
const storecomponents = [
    {
        image:"https://img-fotki.yandex.ru/get/5901/36902536.32/0_a7750_3cf305fa_XL.jpg",
        title:"Пастила из малины",
        description:"Состав: малина 90%, яблочное пюре 10%.",
        price:"Цена: 700тг за 50гр",
    },

    {
        image:"https://mognotak.ru/wp-content/uploads/2018/08/yablochnaya_pastils.jpg",
        title:"Пастила из яблок",
        description:"Состав: Яблочное пюре 100%",
        price:"Цена: 350тг за 50гр",
    },

    {
        image:"https://fruniksy.com/media/102/10203.jpg",
        title:"Пастила из клубники",
        description:"Состав: клубника 90% яблочное пюре 10%.",
        price:"Цена: 750тг за 50гр",
    },

    {
        image:"https://img-global.cpcdn.com/recipes/2abb29bb7a0458c0/680x482cq70/pastila-vishnia-banan-%D0%BE%D1%81%D0%BD%D0%BE%D0%B2%D0%BD%D0%BE%D0%B5-%D1%84%D0%BE%D1%82%D0%BE-%D1%80%D0%B5%D1%86%D0%B5%D0%BF%D1%82%D0%B0.jpg",
        title:"Пастила из вишни",
        description:"Состав: вишня 90%, яблочное пюре 10%.",
        price:"Цена: 700тг за 50гр",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },

    {
        image:"",
        title:"",
        description:"",
        price:"",
    },
];

export default storecomponents;