import {Link} from 'react-router-dom'
import './menu.css'
import Menubar from './Menubar'
import React, {useState} from 'react'






function Header() {
    const [show,setShow]=useState(false)
   
    return(
        

        <div className="section header">
            <div className="container">
                <div className="nav">
                    
                    <div className="links">
                        
                        {
                            show?< Menubar/>:null
                        }


                        <button onClick={()=>setShow(!show)}>Меню</button>
                        
                        <input type="text"></input>
                        

                    </div>
                </div>
            </div>
        </div>  
        
       
            
        
        
    )
}

export default Header;