import React from 'react';
import {Link} from 'react-router-dom'
import log from '../Head/log.png'
import {FcHome} from 'react-icons/fc'
import {FcAbout} from 'react-icons/fc'
import {FcContacts} from 'react-icons/fc'
import {MdLocalGroceryStore} from 'react-icons/md'




function Menubar(){
    
    return(
        <div className="menu">
            <div className="menu-inner">
                <div className="menu-list">
                  <img src={log} />
                  <Link to = "/main" className="links_link"> <FcHome /> Главная</Link>
                  <Link to="/about-page" className="links_link"><FcAbout /> О нас  </Link>
                  <Link to = "/store" className="links_link"><MdLocalGroceryStore/> Магазин</Link>
                  
                  <Link to="/call" className="links_link"><FcContacts />Контакты</Link>
                  
                  
                    

                </div>
            </div>
        </div>
    )
}

export default Menubar